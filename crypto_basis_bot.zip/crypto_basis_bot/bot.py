"""
Spot/perpetual basis scanner + paper-trading Telegram bot.

Important:
- Public market data only. No exchange API keys are used.
- Paper trades only; this code never submits live orders.
- Uses executable order-book sides:
    entry: spot asks (buy), perpetual bids (sell/short)
    exit mark: spot bids (sell), perpetual asks (buy to cover)
- Estimated edge assumes basis convergence to zero. It is NOT a forecast
  and is not guaranteed. Funding is shown as information, not projected
  into profit because future funding is unknown.
"""
import asyncio
import logging
import os
import time
from dataclasses import dataclass
from typing import Optional

import ccxt.async_support as ccxt
from dotenv import load_dotenv
from telegram import Update
from telegram.constants import ParseMode
from telegram.ext import (
    Application, CommandHandler, ContextTypes
)

load_dotenv()

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)
log = logging.getLogger("basis-bot")

TOKEN = os.getenv("TELEGRAM_BOT_TOKEN", "").strip()
ALLOWED_IDS = {
    int(x.strip()) for x in os.getenv("ALLOWED_TELEGRAM_USER_IDS", "").split(",")
    if x.strip().isdigit()
}
SPOT_BUDGET = float(os.getenv("SPOT_BUDGET_USDT", "100"))
SPOT_FEE = float(os.getenv("SPOT_FEE_RATE", "0.001"))
FUT_FEE = float(os.getenv("FUTURES_FEE_RATE", "0.0005"))
SLIPPAGE_BUFFER = float(os.getenv("SLIPPAGE_BUFFER_RATE", "0.0005"))
ORDER_SPLIT = float(os.getenv("ORDER_SPLIT", "0.5"))
SCAN_INTERVAL = int(os.getenv("SCAN_INTERVAL_SECONDS", "20"))
DEPTH_MULTIPLIER = float(os.getenv("MIN_ORDERBOOK_DEPTH_MULTIPLIER", "3"))
MAX_POSITIONS = int(os.getenv("MAX_OPEN_POSITIONS_PER_EXCHANGE", "10"))
MIN_VOLUME = float(os.getenv("MIN_VOLUME_USDT_24H", "100000"))

EXCHANGE_IDS = ("binance", "bybit", "okx")
DB_PATH = "paper_trades.sqlite3"


def allowed(update: Update) -> bool:
    if not ALLOWED_IDS:
        return True
    user = update.effective_user
    return bool(user and user.id in ALLOWED_IDS)


async def deny(update: Update):
    if update.message:
        await update.message.reply_text("Доступ запрещён. Добавьте свой Telegram ID в ALLOWED_TELEGRAM_USER_IDS.")


def db():
    import sqlite3
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("""
        CREATE TABLE IF NOT EXISTS positions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            exchange TEXT NOT NULL,
            symbol TEXT NOT NULL,
            qty REAL NOT NULL,
            spot_entry REAL NOT NULL,
            perp_entry REAL NOT NULL,
            spot_entry_cost REAL NOT NULL,
            perp_entry_value REAL NOT NULL,
            spot_fee_entry REAL NOT NULL,
            perp_fee_entry REAL NOT NULL,
            entry_basis_pct REAL NOT NULL,
            opened_at REAL NOT NULL,
            status TEXT NOT NULL DEFAULT 'OPEN',
            closed_at REAL,
            spot_exit REAL,
            perp_exit REAL,
            net_pnl REAL,
            funding_note TEXT
        )
    """)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS settings (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        )
    """)
    conn.commit()
    return conn


def get_threshold() -> float:
    conn = db()
    row = conn.execute("SELECT value FROM settings WHERE key='threshold_pct'").fetchone()
    conn.close()
    return float(row["value"]) if row else 3.0


def set_threshold(value: float):
    conn = db()
    conn.execute(
        "INSERT INTO settings(key,value) VALUES('threshold_pct',?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        (str(value),),
    )
    conn.commit()
    conn.close()


def search_enabled() -> bool:
    conn = db()
    row = conn.execute("SELECT value FROM settings WHERE key='search_enabled'").fetchone()
    conn.close()
    return row["value"] == "1" if row else False


def set_search_enabled(enabled: bool):
    conn = db()
    conn.execute(
        "INSERT INTO settings(key,value) VALUES('search_enabled',?) "
        "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
        ("1" if enabled else "0",),
    )
    conn.commit()
    conn.close()


@dataclass
class ExchangeClient:
    name: str
    client: object


async def make_exchanges():
    clients = []
    for exchange_id in EXCHANGE_IDS:
        klass = getattr(ccxt, exchange_id)
        client = klass({
            "enableRateLimit": True,
            "timeout": 15000,
            "options": {"defaultType": "spot"},
        })
        clients.append(ExchangeClient(exchange_id, client))
    await asyncio.gather(*(x.client.load_markets() for x in clients), return_exceptions=True)
    return clients


def get_spot_and_swap_symbols(client):
    spot = {}
    swap = {}
    for symbol, market in client.markets.items():
        if market.get("quote") != "USDT" or not market.get("active", True):
            continue
        if market.get("spot") and market.get("base"):
            spot[market["base"]] = symbol
        if market.get("swap") and market.get("linear") and market.get("base"):
            swap[market["base"]] = symbol
    common = set(spot) & set(swap)
    return [(spot[b], swap[b]) for b in common]


def orderbook_vwap(levels, qty):
    """Return VWAP and filled qty for consuming [price, amount] levels."""
    remaining = qty
    notional = 0.0
    filled = 0.0
    for price, amount in levels or []:
        take = min(remaining, float(amount))
        if take <= 0:
            continue
        notional += take * float(price)
        filled += take
        remaining -= take
        if remaining <= max(qty * 1e-9, 1e-12):
            break
    if filled <= 0 or remaining > max(qty * 1e-6, 1e-10):
        return None, filled
    return notional / filled, filled


async def safe_fetch_order_book(client, symbol, limit=50):
    try:
        return await client.fetch_order_book(symbol, limit)
    except Exception as exc:
        log.debug("order book failed %s %s: %s", client.id, symbol, exc)
        return None


async def funding_rate(client, swap_symbol):
    try:
        if client.has.get("fetchFundingRate"):
            data = await client.fetch_funding_rate(swap_symbol)
            return data.get("fundingRate")
    except Exception:
        pass
    return None


def fmt(value, digits=6):
    return f"{value:,.{digits}f}"


def open_positions(exchange=None):
    conn = db()
    if exchange:
        rows = conn.execute(
            "SELECT * FROM positions WHERE status='OPEN' AND exchange=? ORDER BY opened_at DESC",
            (exchange,),
        ).fetchall()
    else:
        rows = conn.execute(
            "SELECT * FROM positions WHERE status='OPEN' ORDER BY opened_at DESC"
        ).fetchall()
    conn.close()
    return rows


def create_position(exchange, symbol, qty, spot_vwap, perp_vwap, funding):
    spot_cost = qty * spot_vwap
    perp_value = qty * perp_vwap
    spot_fee = spot_cost * SPOT_FEE
    perp_fee = perp_value * FUT_FEE
    basis_pct = (perp_vwap / spot_vwap - 1) * 100
    conn = db()
    cur = conn.execute("""
        INSERT INTO positions(
            exchange,symbol,qty,spot_entry,perp_entry,spot_entry_cost,
            perp_entry_value,spot_fee_entry,perp_fee_entry,entry_basis_pct,
            opened_at,funding_note
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
    """, (
        exchange, symbol, qty, spot_vwap, perp_vwap, spot_cost, perp_value,
        spot_fee, perp_fee, basis_pct, time.time(),
        "Текущий funding при входе: " + (f"{funding*100:.5f}%" if funding is not None else "недоступен"),
    ))
    conn.commit()
    pid = cur.lastrowid
    conn.close()
    return pid


async def mark_position(client, row):
    spot_symbol = row["symbol"]
    # Unified CCXT swap symbol is stored in funding_note? derive from base/quote.
    base = spot_symbol.split("/")[0]
    swap_symbol = f"{base}/USDT:USDT"
    if swap_symbol not in client.markets:
        # Some venues use a different unified symbol; find by base.
        candidates = [
            s for s, m in client.markets.items()
            if m.get("swap") and m.get("linear") and m.get("base") == base and m.get("quote") == "USDT"
        ]
        if not candidates:
            return None
        swap_symbol = candidates[0]

    spot_book, perp_book = await asyncio.gather(
        safe_fetch_order_book(client, spot_symbol),
        safe_fetch_order_book(client, swap_symbol),
    )
    if not spot_book or not perp_book:
        return None

    qty = float(row["qty"])
    spot_exit, _ = orderbook_vwap(spot_book.get("bids"), qty)  # sell spot
    perp_exit, _ = orderbook_vwap(perp_book.get("asks"), qty)  # buy back short
    if spot_exit is None or perp_exit is None:
        return None

    spot_proceeds = qty * spot_exit
    perp_close_cost = qty * perp_exit
    exit_fees = spot_proceeds * SPOT_FEE + perp_close_cost * FUT_FEE
    gross = (spot_proceeds - row["spot_entry_cost"]) + (row["perp_entry_value"] - perp_close_cost)
    total_fees = row["spot_fee_entry"] + row["perp_fee_entry"] + exit_fees
    return {
        "spot_exit": spot_exit,
        "perp_exit": perp_exit,
        "gross": gross,
        "fees": total_fees,
        "net": gross - total_fees,
        "basis_pct": (perp_exit / spot_exit - 1) * 100 if spot_exit else 0,
    }


async def scan_exchange(ex, app):
    client = ex.client
    pairs = get_spot_and_swap_symbols(client)
    # Keep scanning bounded; prioritize liquid spot markets by ticker quote volume.
    try:
        tickers = await client.fetch_tickers()
    except Exception:
        tickers = {}

    candidates = []
    for spot_symbol, swap_symbol in pairs:
        ticker = tickers.get(spot_symbol) or {}
        quote_volume = ticker.get("quoteVolume") or 0
        if quote_volume and quote_volume < MIN_VOLUME:
            continue
        candidates.append((spot_symbol, swap_symbol, quote_volume))
    candidates.sort(key=lambda x: x[2] or 0, reverse=True)
    candidates = candidates[:100]

    # Fetch orderbooks in small batches to avoid rate-limit bursts.
    for start in range(0, len(candidates), 10):
        batch = candidates[start:start + 10]
        books = await asyncio.gather(*[
            asyncio.gather(
                safe_fetch_order_book(client, s),
                safe_fetch_order_book(client, p),
            ) for s, p, _ in batch
        ])
        for (spot_symbol, swap_symbol, quote_volume), (spot_book, perp_book) in zip(batch, books):
            if not spot_book or not perp_book:
                continue
            asks = spot_book.get("asks") or []
            bids = perp_book.get("bids") or []
            if not asks or not bids:
                continue

            # Two-part spot order, both simulated against the current ask book.
            budget1 = SPOT_BUDGET * ORDER_SPLIT
            budget2 = SPOT_BUDGET - budget1
            spot_qty1 = budget1 / asks[0][0]
            spot_qty2 = budget2 / asks[0][0]
            qty = spot_qty1 + spot_qty2

            spot_vwap, spot_filled = orderbook_vwap(asks, qty)
            perp_vwap, perp_filled = orderbook_vwap(bids, qty)
            if spot_vwap is None or perp_vwap is None:
                continue

            spot_notional = qty * spot_vwap
            perp_notional = qty * perp_vwap
            # Conservative round-trip cost estimate: entry/exit fees on both legs
            # plus a slippage buffer. Exit depth is validated when marking the position.
            entry_basis = perp_notional - spot_notional
            fee_estimate = spot_notional * SPOT_FEE * 2 + perp_notional * FUT_FEE * 2
            slippage_estimate = (spot_notional + perp_notional) * SLIPPAGE_BUFFER
            estimated_net = entry_basis - fee_estimate - slippage_estimate
            estimated_net_pct = estimated_net / spot_notional * 100 if spot_notional else 0

            if estimated_net <= 0 or estimated_net_pct < get_threshold():
                continue

            existing = [p for p in open_positions(ex.name) if p["symbol"] == spot_symbol]
            if existing:
                continue
            if len(open_positions(ex.name)) >= MAX_POSITIONS:
                continue

            # Depth sanity: require visible top-book depth worth at least configured multiple.
            spot_depth = sum(p * a for p, a in asks[:10])
            perp_depth = sum(p * a for p, a in bids[:10])
            if spot_depth < SPOT_BUDGET * DEPTH_MULTIPLIER or perp_depth < perp_notional * DEPTH_MULTIPLIER:
                continue

            funding = await funding_rate(client, swap_symbol)
            pid = create_position(ex.name, spot_symbol, qty, spot_vwap, perp_vwap, funding)
            message = (
                f"<b>{spot_symbol} [+{estimated_net_pct:.2f}% расчётно]</b>\n"
                f"<b>{ex.name.capitalize()}</b>\n"
                f"<blockquote>• Спот: ${spot_vwap:,.8g}\n"
                f"1) Ордер на покупку #1: ${budget1:.2f}\n"
                f"2) Ордер на покупку #2: ${budget2:.2f}\n"
                f"• Фьючерс: ${perp_vwap:,.8g}\n"
                f"• SHORT: {qty:.8g} {spot_symbol.split('/')[0]}</blockquote>\n"
                f"<b>СИМУЛЯЦИЯ ЗАПУЩЕНА · #{pid}</b>\n"
                f"Куплен SPOT: ${spot_notional:.2f}\n"
                f"Открыт SHORT: ${perp_notional:.2f}\n"
                f"Оценка после расходов: <b>+${estimated_net:.4f}</b>\n"
                f"Funding сейчас: {funding*100:.5f}%"
                if funding is not None else
                f"<b>{spot_symbol} [+{estimated_net_pct:.2f}% расчётно]</b>\n"
                f"<b>{ex.name.capitalize()}</b>\n"
                f"<blockquote>• Спот: ${spot_vwap:,.8g}\n"
                f"1) Ордер на покупку #1: ${budget1:.2f}\n"
                f"2) Ордер на покупку #2: ${budget2:.2f}\n"
                f"• Фьючерс: ${perp_vwap:,.8g}\n"
                f"• SHORT: {qty:.8g} {spot_symbol.split('/')[0]}</blockquote>\n"
                f"<b>СИМУЛЯЦИЯ ЗАПУЩЕНА · #{pid}</b>\n"
                f"Куплен SPOT: ${spot_notional:.2f}\n"
                f"Открыт SHORT: ${perp_notional:.2f}\n"
                f"Оценка после расходов: <b>+${estimated_net:.4f}</b>\n"
                f"Funding сейчас: недоступен"
            )
            await broadcast(app, message)


async def broadcast(app, message):
    for chat_id in app.bot_data.get("chat_ids", set()):
        try:
            await app.bot.send_message(chat_id=chat_id, text=message, parse_mode=ParseMode.HTML)
        except Exception as exc:
            log.warning("Telegram send failed: %s", exc)


async def monitor_positions(app):
    clients = {x.name: x.client for x in app.bot_data["exchanges"]}
    for row in open_positions():
        client = clients.get(row["exchange"])
        if not client:
            continue
        mark = await mark_position(client, row)
        if not mark:
            continue
        msg = (
            f"<b>Симуляция #{row['id']} · {row['symbol']}</b>\n"
            f"Биржа: {row['exchange'].capitalize()}\n"
            f"Текущая расчётная PnL: <b>{mark['net']:+.4f} USDT</b>\n"
            f"Спред сейчас: {mark['basis_pct']:+.3f}%\n"
            f"Спот bid: ${mark['spot_exit']:,.8g}\n"
            f"Фьючерс ask: ${mark['perp_exit']:,.8g}\n"
            f"Комиссии входа и условного выхода учтены.\n"
            f"Funding не включён в PnL."
        )
        # Update message at a restrained cadence; Telegram chat ids are opted-in.
        last = app.bot_data.setdefault("last_position_notice", {})
        now = time.time()
        if now - last.get(row["id"], 0) >= 300:
            await broadcast(app, msg)
            last[row["id"]] = now


async def scan_loop(app):
    while True:
        try:
            if search_enabled():
                for ex in app.bot_data["exchanges"]:
                    try:
                        await scan_exchange(ex, app)
                    except Exception:
                        log.exception("scan failed on %s", ex.name)
            await monitor_positions(app)
        except Exception:
            log.exception("background loop error")
        await asyncio.sleep(SCAN_INTERVAL)


async def post_init(app: Application):
    app.bot_data["chat_ids"] = set()
    app.bot_data["exchanges"] = await make_exchanges()
    app.create_task(scan_loop(app))


async def post_shutdown(app: Application):
    for ex in app.bot_data.get("exchanges", []):
        try:
            await ex.client.close()
        except Exception:
            pass


async def start_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update):
        return await deny(update)
    app = context.application
    app.bot_data.setdefault("chat_ids", set()).add(update.effective_chat.id)
    await update.message.reply_text(
        "Бот запущен. Это PAPER TRADING: реальные ордера не отправляются.\n\n"
        "Команды:\n"
        "/search 3% — искать возможности от 3% чистого расчётного edge\n"
        "/search status — настройки поиска\n"
        "/search off — остановить новые сигналы\n"
        "/positions — открытые симуляции\n"
        "/balance — виртуальный бюджет\n"
        "/profit — текущая суммарная PnL\n"
        "/help — помощь"
    )


async def search_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update):
        return await deny(update)
    if not context.args:
        return await update.message.reply_text("Использование: /search 3% | /search off | /search status")
    arg = context.args[0].lower()
    if arg == "off":
        set_search_enabled(False)
        return await update.message.reply_text("Поиск новых сигналов остановлен. Открытые симуляции продолжают отслеживаться.")
    if arg == "status":
        return await update.message.reply_text(
            f"Поиск: {'ВКЛ' if search_enabled() else 'ВЫКЛ'}\n"
            f"Минимальный чистый расчётный edge: {get_threshold():.3f}%"
        )
    try:
        value = float(arg.replace("%", "").replace(",", "."))
        if value < 0.1 or value > 100:
            raise ValueError()
    except ValueError:
        return await update.message.reply_text("Укажите процент от 0.1 до 100. Пример: /search 3%")
    set_threshold(value)
    set_search_enabled(True)
    context.application.bot_data.setdefault("chat_ids", set()).add(update.effective_chat.id)
    await update.message.reply_text(
        f"Поиск включён на Binance, Bybit и OKX.\n"
        f"Минимальный чистый расчётный edge: {value:.3f}%\n"
        f"Бот будет открывать только виртуальные симуляции."
    )


async def positions_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update):
        return await deny(update)
    rows = open_positions()
    if not rows:
        return await update.message.reply_text("Открытых виртуальных позиций нет.")
    lines = ["<b>Открытые симуляции</b>"]
    for r in rows[:30]:
        lines.append(
            f"#{r['id']} {r['exchange']} {r['symbol']} · qty {r['qty']:.8g} · "
            f"входной спред {r['entry_basis_pct']:.3f}%"
        )
    await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.HTML)


async def balance_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update):
        return await deny(update)
    rows = open_positions()
    spent = {}
    for r in rows:
        spent[r["exchange"]] = spent.get(r["exchange"], 0) + r["spot_entry_cost"]
    lines = ["<b>Виртуальный бюджет</b>", f"Бюджет SPOT на сделку: ${SPOT_BUDGET:.2f}"]
    for ex in EXCHANGE_IDS:
        lines.append(f"{ex.capitalize()}: открыто SPOT на ${spent.get(ex, 0):.2f}")
    lines.append("SHORT-маржа моделируется отдельно; реальные средства не используются.")
    await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.HTML)


async def profit_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not allowed(update):
        return await deny(update)
    rows = open_positions()
    clients = {x.name: x.client for x in context.application.bot_data["exchanges"]}
    total = 0.0
    lines = ["<b>Текущая расчётная PnL</b>"]
    for row in rows:
        mark = await mark_position(clients[row["exchange"]], row)
        if mark:
            total += mark["net"]
            lines.append(f"#{row['id']} {row['exchange']} {row['symbol']}: {mark['net']:+.4f} USDT")
        else:
            lines.append(f"#{row['id']} {row['exchange']} {row['symbol']}: нет свежего стакана")
    lines.append(f"\n<b>Итого: {total:+.4f} USDT</b>")
    lines.append("Funding не включён; PnL оценочная по текущему стакану.")
    await update.message.reply_text("\n".join(lines), parse_mode=ParseMode.HTML)


async def help_cmd(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text(
        "/start — подписаться на сигналы\n"
        "/search N% — включить поиск от чистого расчётного edge N%\n"
        "/search off — остановить новые симуляции\n"
        "/search status — показать порог\n"
        "/positions — открытые позиции\n"
        "/balance — использование виртуального бюджета\n"
        "/profit — текущая оценочная PnL\n\n"
        "Симуляции автоматически открываются при прохождении фильтров. "
        "Закрытие сделок и автофиксация прибыли в этой первой версии не реализованы."
    )


def main():
    if not TOKEN or TOKEN == "put_your_token_here":
        raise SystemExit("Set TELEGRAM_BOT_TOKEN in .env")
    db().close()
    app = (
        Application.builder()
        .token(TOKEN)
        .post_init(post_init)
        .post_shutdown(post_shutdown)
        .build()
    )
    app.add_handler(CommandHandler("start", start_cmd))
    app.add_handler(CommandHandler("search", search_cmd))
    app.add_handler(CommandHandler("positions", positions_cmd))
    app.add_handler(CommandHandler("balance", balance_cmd))
    app.add_handler(CommandHandler("profit", profit_cmd))
    app.add_handler(CommandHandler("help", help_cmd))
    log.info("Starting Telegram paper-trading bot")
    app.run_polling()


if __name__ == "__main__":
    main()
