# Spot/Perpetual Basis Telegram Bot (Paper Trading)

A starter bot that scans Binance, Bybit and OKX public markets and runs **virtual** spot-buy + perpetual-short simulations. It does not place real orders and does not need exchange API keys.

## What it currently does

- `/search 3%` enables scanning with a minimum **estimated net entry basis edge** of 3%.
- `/search off` stops opening new simulations; open simulations keep being monitored.
- `/search status` shows the threshold.
- Scans spot + linear USDT perpetual pairs on Binance, Bybit and OKX.
- Uses order-book asks for spot buys and perpetual bids for opening shorts.
- Checks visible order-book depth and estimates round-trip trading fees plus a configurable slippage buffer.
- Stores paper positions in SQLite.
- `/positions`, `/balance`, `/profit` show paper-trading state.
- Sends periodic mark-to-market updates to subscribed Telegram chats.

## Important limitations (read before relying on results)

This is a first working prototype, not an execution-grade arbitrage engine.

1. **No guaranteed profit.** The threshold is an estimated basis edge assuming the basis eventually converges. It is not a forecast.
2. **No auto-close yet.** The prototype opens paper positions and marks them. A close/exit policy, target basis and stop/risk controls should be added and tested before long unattended runs.
3. **Funding is informational only.** The current funding rate is displayed, but future funding and actual funding payments are not included in PnL.
4. **Fees are configurable estimates.** Set the rates to your actual account tier. Maker/taker schedules vary by venue and account.
5. **Depth is approximate.** Public REST order books can change before a simulated fill; this prototype does not model queue priority or latency.
6. **Budget semantics.** `SPOT_BUDGET_USDT` is the spot-leg budget per simulated trade, per exchange. The matching short is sized to the same base-asset quantity. The required futures collateral is tracked conceptually, not deducted from a shared $100 wallet. This avoids falsely implying that $100 total can always fund both legs.
7. Contract specs differ. CCXT unified symbols and market metadata are used, but exchange-specific edge cases may need handling.

## Install

Python 3.10+ recommended.

```bash
python -m venv .venv
# Windows:
.venv\\Scripts\\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
cp .env.example .env
```

Edit `.env` and set:
- `TELEGRAM_BOT_TOKEN`
- `ALLOWED_TELEGRAM_USER_IDS` to your numeric Telegram user ID

Run:

```bash
python bot.py
```

Open your bot in Telegram and send `/start`, then `/search 3%`.

## Safety

- Never add exchange API keys to this prototype.
- Keep `ALLOWED_TELEGRAM_USER_IDS` configured.
- This bot is paper-only; do not treat its estimates as executable quotes.
